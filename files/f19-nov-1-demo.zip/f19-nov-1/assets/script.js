console.log("local storage demo file");
	
var saveUserInfo = function(){
	if (!storageAvailable('localStorage')){ return; } // if we can use localStorage, don't return

	
	// localStorage.removeItem('color');


	// on first site load
	if(localStorage.getItem('color')){ // using a string
		// if color has been saved: 
		var color = localStorage.getItem('color');

		// apply color to element: 
		document.getElementById("myDiv").style.color = color;

	}


	if(localStorage.getItem('typePixels')){ // using an integer
		var fontSizeValue = parseInt(localStorage.getItem('typePixels'));
		console.log(fontSizeValue);
		var increasedFontSize = fontSizeValue + 20;
		document.getElementById("myDiv").style.fontSize = increasedFontSize + "px";
	}


	if(localStorage.getItem('css')){
		// getting our saved css values:
		var css = localStorage.getItem('css');
		var JSONcss = JSON.parse(css); // converting our string back into an object

		console.log(css, JSONcss);

		document.getElementById("myDiv").style.backgroundColor = JSONcss.backgroundColor;
		document.getElementById("myDiv").style.transform = `skew(${JSONcss.skewValue}deg, ${JSONcss.skewValue}deg)`;

	}







	document.getElementById("myDiv").addEventListener('click', function(){
		// when a user clicks on myDiv, produce a random color to save:

		console.log("clicked!")

		// COLOR:
		var red = Math.round(Math.random()*255);
		var green = Math.round(Math.random()*255);
		var blue = Math.round(Math.random()*255);

		// var newColor = "rgb(" + red + "," + green + "," + blue + ")";
		var newColor = `rgb(${red}, ${green}, ${blue})`;

		localStorage.setItem('color', newColor); // save new color

		// set new color to item:
		document.getElementById("myDiv").style.color = newColor;


		// FONT SIZE:

		var randomFontSize = 20 + (Math.round(Math.random()*30));
		console.log(randomFontSize)
		// randomFontSize = randomFontSize + "px";
		document.getElementById("myDiv").style.fontSize = randomFontSize + "px";

		localStorage.setItem('typePixels', randomFontSize);


		// CSS 

		// create our values:
		var backgroundC = `rgba(${red}, ${green}, ${blue}, 0.5)`;
		var skew = 10 - Math.round(Math.random()*20);

		// save our values in an object:
		var newCSS = {
			skewValue : skew,
			backgroundColor : backgroundC
		}

		// in order to save our object in localStorage, we need to convert
		// it into a string:
		localStorage.setItem('css', JSON.stringify(newCSS));


		document.getElementById("myDiv").style.backgroundColor = backgroundC;
		document.getElementById("myDiv").style.transform = `skew(${skew}deg, ${skew}deg)`;

	})


}


saveUserInfo(); // run saving user info

