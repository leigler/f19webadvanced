// Documentation: https://www.metaweather.com/api/
// New York woeid: 2459115


var fetchingCityWOEID = function(cityString){
	// WOEID is the WHERE ON EARTH IDENTIFIER
	// https://en.wikipedia.org/wiki/WOEID

	var weather = `https://www.metaweather.com/api/location/search/?query=${cityString}`;
	var	query = `https://cors-anywhere.herokuapp.com/${weather}`;


	fetch(query)
	.then(function(results){
		console.log("Request for " + cityString, results); // log unprocessed results
		
		return results.json();
	})
	.then(function(jsonResults){
		console.log(jsonResults) // log converted json results

		var woeid = jsonResults[0].woeid; // get the woeid
		var city = jsonResults[0].title;
		console.log("WOEID:", woeid)

		fetchingWeatherCORS(woeid);

		// use woeid to get the weather information associated with your city
		// fetchingWeatherCORS(woeid);

	})
}


var fetchingWeatherCORS = function(woeid){
	// example uses "cors-anywhere" hack, which allows us to circumvent cors permissions

	var weather = `https://www.metaweather.com/api/location/${woeid}`;
	var query = `https://cors-anywhere.herokuapp.com/${weather}`;

	fetch(query)
	.then(function(results){
		console.log("Request for " + woeid, results); // log unprocessed results
		
		return results.json();
	})
	.then(function(jsonResults){
		
		var firstResult = jsonResults.consolidated_weather[0];

		var windDirection = firstResult.wind_direction;
		var windSpeed = firstResult.wind_speed;

		console.log(windDirection, windSpeed) // log converted json results

		// animation using TweenMax: (and using the values windDirection and windSpeed to influence the animation)

		TweenMax.to(".bouncing_ball", 3, {scale: 1.4, y: "-90vh", yoyo: true, repeat: -1, ease: Power2.easeOut, rotation: 360})
		TweenMax.to("#city_element", 2, {skewX: 20, rotation: windDirection, y: `-${windSpeed}px`, yoyo: true, repeat: -1 })
		TweenMax.to("#city_element", 4, {width: "200px", ease: Elastic.easeInOut.config(1, 0.3), yoyo: true, repeat: -1})
		TweenMax.fromTo("#city_element", 4, {delay: 2, backgroundColor: "red"}, {backgroundColor: "yellow", yoyo: true, repeat: -1})

	})

}



document.addEventListener('DOMContentLoaded', function(event) {
	// once the document has loaded lets run our functions: 
	fetchingCityWOEID("New York"); // look for New York's WOEID
	// fetchingWeatherCORS(2459115); // could be used if we know this specific ID

})








