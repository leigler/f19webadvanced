/*==========================================*/
console.log("\n~script has loaded~\n\n");
/*==========================================*/

// query selectors
	// query selectors are used to get 
	// specific elements or groups of elements from
	// your HTML Document

	/* Returns a single element: */
	var myDiv = document.getElementById("myFirstDiv");
	var theSameDiv = document.querySelector("#myFirstDiv");
	var ourButton = document.querySelector("#myFirstDiv button");
	// console.log(ourButton);

	var listItem = document.querySelector(".list_item");

	// console.log(listItem);


	/* Returns an array of elements: */
	var listItems = document.getElementsByClassName("list_item");
	// console.log(listItems)

	var sameListItems = document.querySelectorAll("div");
	// console.log(sameListItems)




// event listeners
// event listeners are used to introduce interactivity:

	var myButton = document.querySelector("#turnRed");
	var circle = document.querySelector("#circle");


	// a simple toggle (on and off state) 
	var isThisRed = false; // this variable keeps track of whether your button is on or off
	var turnThisRed = function(){		
		if(isThisRed === false){
			myButton.style.backgroundColor = "red";
			circle.style.backgroundColor = "red";
			isThisRed = true;
		}else{
			myButton.style.backgroundColor = "white";
			circle.style.backgroundColor = "black";
			isThisRed = false;
		}
	}



	// another example of an on/off toggle, this time with fontFamily:
	var typeTimes = false;

	var changeTypeface = function(){
		if(typeTimes === false){
			myButton.style.fontFamily = "Times";
			typeTimes = true;
		}else{
			myButton.style.fontFamily = "Arial";
			typeTimes = false;
		}
		
	}


	// for both of the above examples, we will want to bind the event listener to its corresponding HTML element: 
	myButton.addEventListener("click", turnThisRed)
	myButton.addEventListener("mouseover", changeTypeface)
	myButton.addEventListener("mouseout", changeTypeface)
	


	// object example:
	var myObject = {
		variable: "string saved",
		otherValue : 22
	}

	// objects are accessed with dot "." notation:
	// myObject.otherValue



	// a function attached to your mousemovement changing background color:

	var backgroundColorChange = function(event){

		var widthOfBrowser = window.innerWidth;
		var heightOfBrowser = window.innerHeight;

		// console.log("browser size: ", widthOfBrowser, heightOfBrowser)
		// console.log("mouse position: ", event.pageX, event.pageY)

		var body = document.querySelector("body");

		var percentageX = event.pageX/widthOfBrowser;
		var red = 100 + (155 * (percentageX));

		var percentageY = event.pageY/heightOfBrowser;
		var blue = 255 * (percentageY);

		body.style.backgroundColor = `rgb(${ red },0,${blue})`;

	}

	// event listener: 
	window.addEventListener("mousemove", backgroundColorChange)



	/****** SCROLLING: ******/

	var scrolling = function(){
		var body = document.querySelector("body");
		// console.log("window.scrollY", window.scrollY)
		// console.log("window.innerHeight", window.innerHeight)
		// console.log("body.offsetHeight: ", body.offsetHeight)

		var percentageScrolled = (window.scrollY + window.innerHeight)/body.offsetHeight;
		console.log(percentageScrolled)

		if(percentageScrolled >= 1 ){
			window.scrollTo(0,0)
		}

	}


	window.addEventListener("scroll", scrolling);






